# Ohmega Spyglass — Minecraft 26.3 / NeoForge 26.3.0.48-beta

Compatibility add-on for **Ohmega 1.5.21 NeoForge 26.3**.

## Implemented behavior

- Adds one dedicated accessory slot after Ohmega's configured slots.
- The slot uses Ohmega's **Normal** slot appearance/text, but internally has its own accessory type so only the vanilla Spyglass is routed to it.
- Makes `minecraft:spyglass` an Ohmega accessory without replacing a third-party binding if one already exists.
- Adds **Zoom de Catalejo / Spyglass Zoom** to the existing Ohmega key category in Controls. Default: **C**, fully rebindable.
- Zoom only works while the Spyglass is equipped in the dedicated Ohmega slot.
- Smooth 4x OptiFine-style FOV zoom; no vanilla spyglass vignette and no need to hold the item.
- Renders the equipped Spyglass as a 3D item attached to the **left leg**, moving with the leg animation.
- Default 3D item scale is **0.50**, matching the item-render scale used by Archery Things' quiver renderer on 26.3.
- Adds client config values under `spyglassRender`: `x`, `y`, `z`, `scale`.
- Expands Ohmega 1.5.21's hard-coded shift-click accessory bound so the added slot can be shift-clicked out correctly.

## Target versions

- Minecraft: **26.3**
- NeoForge build used by this project: **26.3.0.48-beta**
- NeoForge loader: **4+**
- Ohmega: **1.5.21** (dependency range intentionally stops before 1.6)
- Java: **25**
- Gradle fallback used by the Windows build script: **9.5.0**

## Build

1. Install a **Java 25 JDK** and make sure `java` is in PATH.
2. Either allow Gradle to resolve Ohmega 1.5.21 from Modrinth Maven, or copy your existing Ohmega jar to:
   `libs/ohmega-1.5.21-neoforge-mc26.3.jar`
3. On Windows run:
   `powershell -ExecutionPolicy Bypass -File .\build-windows.ps1`
   The script downloads Gradle 9.5.0 if Gradle is not already installed.
4. If Gradle is already installed on any OS, `gradle build` also works.
5. The resulting jar is written to `build/libs/`.
6. Put that jar in the same `mods` folder as Ohmega 1.5.21.

## 26.3 port changes

The port updates the project to Java 25, NeoForge ModDevGradle 2.0.147 and NeoForge 26.3.0.48-beta. It also adapts the key mapping to 26.3's `InputConstants.Type.KEYBOARD`, updates the player-layer transform to 26.3's `PoseStack.rotateDegrees(...)`, and adapts zoom to the 26.3 `ViewportEvent.ComputeFov`, which no longer exposes the 1.21.11 `usedConfiguredFov()` flag.

The Ohmega integration remains based on the 1.5.x APIs that are still present in Ohmega 1.5.21: `AccessoryHelper`, `AccessoryType`, the accessory type registration/override events, the accessory container, and the same accessory inventory layout. Ohmega 1.5.21 on 26.3 still has the `52` shift-click upper bound, so the mixin continues to replace it with the actual accessory slot count.

## Position defaults

The Spyglass is parented to `PlayerModel.leftLeg`, then rendered with a fixed holster orientation.

- X: 0.25
- Y: 0.28
- Z: 0.05
- Scale: 0.50

Change them through the mod configuration screen. Because it is attached to the leg bone, the position follows walking and crouching animations rather than floating independently of the player model.

## Notes

The dedicated slot is injected at runtime instead of rewriting Ohmega's server config file. Removing this add-on cleanly returns Ohmega to its original slot list. The custom slot is deliberately appended last so Ohmega places it after other integrations such as Elytra, Totem and Quiver, including moving it into the next/right-hand column when the current column is full.
