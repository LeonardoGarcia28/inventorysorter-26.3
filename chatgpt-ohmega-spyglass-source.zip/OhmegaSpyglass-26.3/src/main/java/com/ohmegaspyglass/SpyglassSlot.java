package com.ohmegaspyglass;

import com.google.common.collect.ImmutableList;
import com.swacky.ohmega.api.AccessoryHelper;
import com.swacky.ohmega.common.accessorytype.AccessoryType;
import com.swacky.ohmega.common.accessorytype.AccessoryTypeManager;
import com.swacky.ohmega.common.dataattachment.AccessoryContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class SpyglassSlot {
    private SpyglassSlot() {}

    /**
     * Finds the dedicated spyglass slot in Ohmega's effective slot list.
     * The mixin appends it last, but resolving by type also remains safe if another add-on
     * post-processes the slot list after ours.
     */
    public static int index() {
        if (!AccessoryTypeManager.exists(OhmegaSpyglass.SPYGLASS_TYPE_ID.toString())) {
            return -1;
        }

        AccessoryType spyglassType = AccessoryTypeManager.get(OhmegaSpyglass.SPYGLASS_TYPE_ID);
        ImmutableList<AccessoryType> slotTypes = AccessoryHelper.getSlotTypes();

        for (int i = slotTypes.size() - 1; i >= 0; i--) {
            if (spyglassType.equals(slotTypes.get(i))) {
                return i;
            }
        }

        return -1;
    }

    public static ItemStack getEquipped(Player player) {
        AccessoryContainer container = AccessoryHelper.getContainer(player);
        int index = index();

        if (index < 0 || index >= container.getSlots()) {
            return ItemStack.EMPTY;
        }

        ItemStack stack = container.getStackInSlot(index);
        return stack.is(Items.SPYGLASS) ? stack : ItemStack.EMPTY;
    }

    public static boolean isEquipped(Player player) {
        return !getEquipped(player).isEmpty();
    }
}
