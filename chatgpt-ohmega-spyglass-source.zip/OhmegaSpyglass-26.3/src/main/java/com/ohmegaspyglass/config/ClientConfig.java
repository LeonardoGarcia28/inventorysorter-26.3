package com.ohmegaspyglass.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class ClientConfig {
    public static final ModConfigSpec SPEC;

    private static final ModConfigSpec.DoubleValue X;
    private static final ModConfigSpec.DoubleValue Y;
    private static final ModConfigSpec.DoubleValue Z;
    private static final ModConfigSpec.DoubleValue SCALE;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();

        builder.push("spyglassRender");
        X = builder
                .comment("Left/right position of the equipped spyglass relative to the left leg.")
                .defineInRange("x", 0.25D, -2.0D, 2.0D);
        Y = builder
                .comment("Up/down position of the equipped spyglass relative to the left leg. Positive values move down in model space.")
                .defineInRange("y", 0.28D, -2.0D, 2.0D);
        Z = builder
                .comment("Front/back position of the equipped spyglass relative to the left leg.")
                .defineInRange("z", 0.05D, -2.0D, 2.0D);
        SCALE = builder
                .comment("3D spyglass scale. Default 0.5 matches Archery Things' quiver item-render scale.")
                .defineInRange("scale", 0.50D, 0.05D, 3.0D);
        builder.pop();

        SPEC = builder.build();
    }

    private ClientConfig() {}

    public static double x() {
        return X.get();
    }

    public static double y() {
        return Y.get();
    }

    public static double z() {
        return Z.get();
    }

    public static float scale() {
        return SCALE.get().floatValue();
    }
}
