package com.ohmegaspyglass;

import com.ohmegaspyglass.client.ClientBootstrap;
import com.swacky.ohmega.api.AccessoryHelper;
import com.swacky.ohmega.api.IAccessory;
import com.swacky.ohmega.api.event.AccessoryOverrideTypesEvent;
import com.swacky.ohmega.api.event.RegisterAccessoryTypesEvent;
import com.swacky.ohmega.common.OhmegaCommon;
import com.swacky.ohmega.common.accessorytype.AccessoryType;
import com.swacky.ohmega.common.accessorytype.AccessoryTypeManager;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Items;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

@Mod(OhmegaSpyglass.MODID)
public final class OhmegaSpyglass {
    public static final String MODID = "ohmega_spyglass";
    public static final Identifier SPYGLASS_TYPE_ID = Identifier.fromNamespaceAndPath(MODID, "spyglass");

    private static final IAccessory SPYGLASS_ACCESSORY = new IAccessory() {};

    public OhmegaSpyglass(IEventBus modBus, Dist dist, ModContainer container) {
        // Register our dedicated accessory type on Ohmega's reload event.
        NeoForge.EVENT_BUS.addListener(OhmegaSpyglass::onRegisterAccessoryTypes);
        modBus.addListener(OhmegaSpyglass::onAccessoryOverrideTypes);

        // Vanilla spyglasses are not accessories by default. Keep an existing third-party
        // binding if another mod already supplied one.
        if (!AccessoryHelper.isItemAccessoryBound(Items.SPYGLASS)) {
            AccessoryHelper.bindAccessory(Items.SPYGLASS, SPYGLASS_ACCESSORY);
        }

        if (dist.isClient()) {
            ClientBootstrap.bootstrap(modBus, container);
        }
    }

    private static void onRegisterAccessoryTypes(RegisterAccessoryTypesEvent event) {
        AccessoryType type = new AccessoryType.Builder()
                .emptySlotPath(OhmegaCommon.id("accessory_slot_normal"))
                .priority(Integer.MAX_VALUE)
                .build(MODID, "spyglass");
        event.types.add(type);
    }

    private static void onAccessoryOverrideTypes(AccessoryOverrideTypesEvent event) {
        if (AccessoryTypeManager.exists(SPYGLASS_TYPE_ID.toString())) {
            event.overrideRemaps.put(Items.SPYGLASS, AccessoryTypeManager.get(SPYGLASS_TYPE_ID));
        }
    }
}
