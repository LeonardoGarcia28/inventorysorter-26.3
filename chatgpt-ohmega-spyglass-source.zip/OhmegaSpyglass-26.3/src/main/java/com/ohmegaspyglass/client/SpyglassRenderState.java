package com.ohmegaspyglass.client;

import net.minecraft.world.item.ItemStack;

public interface SpyglassRenderState {
    ItemStack ohmegaSpyglass$getStack();
    void ohmegaSpyglass$setStack(ItemStack stack);
}
