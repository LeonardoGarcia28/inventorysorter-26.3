package com.ohmegaspyglass.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.ohmegaspyglass.SpyglassSlot;
import com.swacky.ohmega.common.init.OhmegaBinds;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.PlayerModelType;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

public final class ClientEvents {
    public static final KeyMapping ZOOM = new KeyMapping(
            "key.ohmega_spyglass.zoom",
            InputConstants.Type.KEYBOARD,
            InputConstants.KEY_C,
            OhmegaBinds.CATEGORY);

    private static final float ZOOM_DIVISOR = 4.0F;
    private static final float STEP_PER_TICK = 0.25F;

    private static float previousZoom = 0.0F;
    private static float zoom = 0.0F;

    private ClientEvents() {}

    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        // Ohmega registers the shared category. We only add our rebindable action to it.
        event.register(ZOOM);
    }

    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        for (PlayerModelType skinType : event.getSkins()) {
            var renderer = event.getPlayerRenderer(skinType);
            if (renderer != null) {
                renderer.addLayer(new SpyglassLayer<>(renderer));
            }
        }
    }

    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        previousZoom = zoom;

        boolean active = mc.player != null
                && mc.level != null
                && mc.screen == null
                && ZOOM.isDown()
                && SpyglassSlot.isEquipped(mc.player);

        if (active) {
            zoom = Math.min(1.0F, zoom + STEP_PER_TICK);
        } else {
            zoom = Math.max(0.0F, zoom - STEP_PER_TICK);
        }
    }

    public static void onComputeFov(ViewportEvent.ComputeFov event) {
        // In NeoForge 26.3 ComputeFov is emitted from Camera#calculateFov.
        // Unlike 1.21.11 it no longer carries usedConfiguredFov(), so apply the
        // multiplier directly to the camera FOV while the smooth transition is active.
        if (previousZoom <= 0.0F && zoom <= 0.0F) {
            return;
        }

        float partialTick = Mth.clamp(event.getPartialTick(), 0.0F, 1.0F);
        float progress = Mth.lerp(partialTick, previousZoom, zoom);
        float smooth = progress * progress * (3.0F - 2.0F * progress);
        float multiplier = Mth.lerp(smooth, 1.0F, 1.0F / ZOOM_DIVISOR);
        event.setFOV(event.getFOV() * multiplier);
    }
}
