package com.ohmegaspyglass.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.ohmegaspyglass.config.ClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public final class SpyglassLayer<S extends HumanoidRenderState, M extends HumanoidModel<S>> extends RenderLayer<S, M> {
    public SpyglassLayer(RenderLayerParent<S, M> renderer) {
        super(renderer);
    }

    @Override
    public void submit(PoseStack poseStack, SubmitNodeCollector nodeCollector, int packedLight,
                       S renderState, float yRot, float partialTick) {
        if (renderState.isInvisible || !(renderState instanceof SpyglassRenderState stateAccess)) {
            return;
        }

        ItemStack spyglass = stateAccess.ohmegaSpyglass$getStack();
        if (spyglass == null || spyglass.isEmpty()) {
            return;
        }

        ItemModelResolver resolver = new ItemModelResolver(Minecraft.getInstance().getModelManager());
        ItemStackRenderState itemState = new ItemStackRenderState();
        resolver.updateForTopItem(itemState, spyglass, ItemDisplayContext.FIXED, null, null, 1);

        poseStack.pushPose();

        // Parent the item to the LEFT leg so walking/crouching animation carries it naturally.
        getParentModel().leftLeg.translateAndRotate(poseStack);

        poseStack.translate(ClientConfig.x(), ClientConfig.y(), ClientConfig.z());

        // 26.3's PoseStack exposes rotateDegrees directly.
        poseStack.rotateDegrees(Axis.ZN, 90.0F);
        poseStack.rotateDegrees(Axis.XN, 90.0F);

        float scale = ClientConfig.scale();
        poseStack.scale(scale, scale, scale);

        itemState.submit(
                poseStack,
                nodeCollector,
                packedLight,
                OverlayTexture.NO_OVERLAY,
                renderState.outlineColor);

        poseStack.popPose();
    }
}
