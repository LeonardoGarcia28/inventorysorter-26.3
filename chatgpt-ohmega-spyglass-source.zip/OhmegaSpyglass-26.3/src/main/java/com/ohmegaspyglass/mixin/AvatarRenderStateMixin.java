package com.ohmegaspyglass.mixin;

import com.ohmegaspyglass.client.SpyglassRenderState;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(AvatarRenderState.class)
public abstract class AvatarRenderStateMixin implements SpyglassRenderState {
    @Unique
    private ItemStack ohmegaSpyglass$stack = ItemStack.EMPTY;

    @Override
    public ItemStack ohmegaSpyglass$getStack() {
        return ohmegaSpyglass$stack;
    }

    @Override
    public void ohmegaSpyglass$setStack(ItemStack stack) {
        ohmegaSpyglass$stack = stack == null ? ItemStack.EMPTY : stack;
    }
}
