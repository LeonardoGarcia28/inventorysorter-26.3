package com.ohmegaspyglass.mixin;

import com.ohmegaspyglass.SpyglassSlot;
import com.ohmegaspyglass.client.SpyglassRenderState;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class AvatarRendererMixin {
    @Inject(
            method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V",
            at = @At("TAIL"))
    private void ohmegaSpyglass$captureEquippedSpyglass(
            Avatar avatar,
            AvatarRenderState renderState,
            float partialTick,
            CallbackInfo ci) {
        ItemStack stack = ItemStack.EMPTY;
        if (avatar instanceof Player player) {
            stack = SpyglassSlot.getEquipped(player);
        }
        ((SpyglassRenderState) renderState).ohmegaSpyglass$setStack(stack);
    }
}
