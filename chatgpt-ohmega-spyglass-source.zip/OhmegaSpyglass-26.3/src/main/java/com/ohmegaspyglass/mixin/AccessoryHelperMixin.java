package com.ohmegaspyglass.mixin;

import com.google.common.collect.ImmutableList;
import com.ohmegaspyglass.OhmegaSpyglass;
import com.swacky.ohmega.api.AccessoryHelper;
import com.swacky.ohmega.common.accessorytype.AccessoryType;
import com.swacky.ohmega.common.accessorytype.AccessoryTypeManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = AccessoryHelper.class, remap = false)
public abstract class AccessoryHelperMixin {
    @Inject(method = "getSlotTypes", at = @At("RETURN"), cancellable = true, remap = false)
    private static void ohmegaSpyglass$appendDedicatedSlot(CallbackInfoReturnable<ImmutableList<AccessoryType>> cir) {
        if (!AccessoryTypeManager.exists(OhmegaSpyglass.SPYGLASS_TYPE_ID.toString())) {
            return;
        }

        AccessoryType spyglassType = AccessoryTypeManager.get(OhmegaSpyglass.SPYGLASS_TYPE_ID);
        ImmutableList<AccessoryType> original = cir.getReturnValue();
        ImmutableList.Builder<AccessoryType> builder = ImmutableList.builderWithExpectedSize(original.size() + 1);

        // Keep exactly one spyglass slot, always at the end. This places it after Elytra/Totem/Quiver
        // integrations and lets Ohmega naturally move it into the column to their right when needed.
        for (AccessoryType type : original) {
            if (!type.equals(spyglassType)) {
                builder.add(type);
            }
        }
        builder.add(spyglassType);
        cir.setReturnValue(builder.build());
    }
}
