package com.ohmegaspyglass.mixin;

import com.swacky.ohmega.api.AccessoryHelper;
import com.swacky.ohmega.common.inv.AccessoryInventoryMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(value = AccessoryInventoryMenu.class, remap = false)
public abstract class AccessoryInventoryMenuMixin {
    /**
     * Ohmega 1.5.21 hard-codes the shift-click accessory upper bound to 52 (= 46 + six slots).
     * The spyglass adds one more slot, so make that bound follow the actual slot count.
     */
    @ModifyConstant(method = "quickMoveStack", constant = @Constant(intValue = 52), remap = false)
    private int ohmegaSpyglass$expandAccessoryShiftClickRange(int original) {
        return 46 + AccessoryHelper.getSlotTypes().size();
    }
}
