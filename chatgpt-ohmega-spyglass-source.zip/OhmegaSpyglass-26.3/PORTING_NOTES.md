# Porting notes: 1.21.11 -> 26.3

Target: Minecraft 26.3, NeoForge 26.3.0.48-beta, Ohmega 1.5.21.

Changes applied:

- Java toolchain: 21 -> 25.
- NeoForge ModDevGradle: 2.0.134 -> 2.0.147.
- Removed the old Parchment block; the 26.3 target uses the current NeoForge/NeoForm names directly.
- Updated NeoForge metadata to the current `javafml` form with loader range `[4,)`.
- Ohmega compile dependency: 1.5.16 / 1.21.11 -> 1.5.21 / 26.3 (Modrinth version `ClXNshd9`).
- Key input type: `InputConstants.Type.KEYSYM` -> `InputConstants.Type.KEYBOARD`.
- Default C key now uses `InputConstants.KEY_C` instead of GLFW directly.
- FOV event: removed `usedConfiguredFov()` handling because NeoForge 26.3's `ViewportEvent.ComputeFov` no longer has that field.
- Player layer transforms: changed `mulPose(Axis.*.rotationDegrees(...))` to the 26.3 `PoseStack.rotateDegrees(Axis, degrees)` form.
- Kept the `AvatarRenderer.extractRenderState(Avatar, AvatarRenderState, float)` hook; the same descriptor is used in 26.3.
- Kept the Ohmega `AccessoryInventoryMenu` constant patch because Ohmega 1.5.21 still uses `index < 52` for accessory shift-click removal.
- Made equipped-slot lookup resolve the dedicated accessory type's actual index instead of assuming the container's final slot, improving compatibility with other slot-extending add-ons.
