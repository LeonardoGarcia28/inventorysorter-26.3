Optional offline dependency:
Copy your existing Ohmega 26.3 NeoForge jar here with this exact name:
  ohmega-1.5.21-neoforge-mc26.3.jar

If the file is absent, Gradle resolves Ohmega 1.5.21 NeoForge 26.3 from Modrinth Maven.
