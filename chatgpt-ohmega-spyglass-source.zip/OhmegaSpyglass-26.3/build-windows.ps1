$ErrorActionPreference = 'Stop'

Write-Host 'Ohmega Spyglass build - Minecraft 26.3 / NeoForge 26.3.0.48-beta' -ForegroundColor Cyan

$java = Get-Command java -ErrorAction SilentlyContinue
if (-not $java) {
    throw 'Java 25 is required and java.exe was not found in PATH.'
}

$versionText = (& java -version 2>&1 | Select-Object -First 1)
Write-Host "Using $versionText"

$majorMatch = [regex]::Match($versionText, '"(?<major>\d+)')
if ($majorMatch.Success -and [int]$majorMatch.Groups['major'].Value -lt 25) {
    throw "Java 25 or newer is required. Detected: $versionText"
}

$gradle = Get-Command gradle -ErrorAction SilentlyContinue
if ($gradle) {
    & gradle build
} else {
    $gradleVersion = '9.5.0'
    $tools = Join-Path $PSScriptRoot '.gradle-local'
    $home = Join-Path $tools "gradle-$gradleVersion"
    $zip = Join-Path $tools "gradle-$gradleVersion-bin.zip"

    New-Item -ItemType Directory -Force -Path $tools | Out-Null

    if (-not (Test-Path $home)) {
        if (-not (Test-Path $zip)) {
            Write-Host "Downloading Gradle $gradleVersion..."
            Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip" -OutFile $zip
        }
        Write-Host 'Extracting Gradle...'
        Expand-Archive -Path $zip -DestinationPath $tools -Force
    }

    & (Join-Path $home 'bin\gradle.bat') build
}

if ($LASTEXITCODE -ne 0) {
    throw "Gradle build failed with exit code $LASTEXITCODE"
}

Write-Host ''
Write-Host 'Build complete. Jar(s):' -ForegroundColor Green
Get-ChildItem (Join-Path $PSScriptRoot 'build\libs\*.jar') | ForEach-Object { Write-Host $_.FullName }
